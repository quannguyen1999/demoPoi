package com.example.demoPoi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoPoiApplicationTests {

	@Test
	void contextLoads() {
	}

}
