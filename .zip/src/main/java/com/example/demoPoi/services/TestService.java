package com.example.demoPoi.services;

public interface TestService {
    void handlerData(byte[] data);
}
