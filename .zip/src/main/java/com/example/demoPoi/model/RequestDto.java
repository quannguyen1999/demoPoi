package com.example.demoPoi.model;

import lombok.Data;

@Data
public class RequestDto {
    byte[] data;
}
