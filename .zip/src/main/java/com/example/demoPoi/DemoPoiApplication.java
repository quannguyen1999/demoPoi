package com.example.demoPoi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoPoiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoPoiApplication.class, args);
	}

}
